import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.css']
})
export class MakePaymentComponent implements OnInit {
  router:Router;
  constructor(router:Router) {
    this.router=router;
   }
  add(){
    this.router.navigateByUrl('app-summary');
  }
  ngOnInit() {
  }

}
