import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html',
  styleUrls: ['./order-summary.component.css']
})
export class OrderSummaryComponent implements OnInit {
  router:Router;
  constructor(router:Router) {
    this.router=router;
   }
  add(){
    this.router.navigateByUrl('app-billing-details');
  }
  ngOnInit() {
  }

 

}
