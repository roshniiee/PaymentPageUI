import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-billing-details',
  templateUrl: './billing-details.component.html',
  styleUrls: ['./billing-details.component.css']
})
export class BillingDetailsComponent implements OnInit {
  router:Router;
  constructor(router:Router) {
    this.router=router;
   }
  add(){
    this.router.navigateByUrl('app-make-payment');
  }
  ngOnInit() {
  }

}
