import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { BillingDetailsComponent } from './billing-details/billing-details.component';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { SummaryComponent } from './summary/summary.component';
const routes: Routes = [
  {
     path:'app-order-summary',
     component:OrderSummaryComponent
  },
  {
    path:'app-billing-details',
    component:BillingDetailsComponent
 },
 {
  path:'app-make-payment',
  component:MakePaymentComponent
},
{
  path:'app-summary',
  component:SummaryComponent
}
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
